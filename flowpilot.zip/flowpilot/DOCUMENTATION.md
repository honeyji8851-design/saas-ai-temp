dard" id="34127"}
# FlowPilot – Workflow Automation SaaS Template

## Overview
FlowPilot is a modern SaaS landing page template designed for automation platforms, startups, and technology products.

Built using Next.js, React, Tailwind CSS, and TypeScript.

## Installation

1. Extract the template
2. Open the folder in Visual Studio Code
3. Run the following commands:

npm install  
npm run dev

4. Open your browser:

http://localhost:3000

## Tech Stack
Next.js  
React  
Tailwind CSS  
TypeScript

## Folder Structure

src/app – pages  
src/components – UI components  
public – static assets

## Customization
Edit text and sections inside the components folder.

## Support
Contact the template author for custo