import { Navbar } from "@/components/layout/Navbar";

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <main className="pt-32 px-6">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-5xl font-bold tracking-tight mb-8">Our mission is to give you back your time.</h1>
          <div className="prose prose-zinc prose-lg">
            <p className="text-zinc-600 leading-relaxed mb-6">
              FlowPilot was founded in 2024 by a group of engineers who were tired of "work about work." 
              We believe that automation should be accessible, intuitive, and invisible.
            </p>
            <p className="text-zinc-600 leading-relaxed">
              Today, thousands of teams use FlowPilot to run their back-office operations, 
              customer success pipelines, and data syncs without writing a single line of code.
            </p>
          </div>
          
          <div className="mt-20 grid grid-cols-2 gap-12 border-t border-zinc-100 pt-12">
            <div>
              <div className="text-3xl font-bold mb-2">1B+</div>
              <div className="text-zinc-500 text-sm uppercase tracking-wider">Tasks Automated</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">99.99%</div>
              <div className="text-zinc-500 text-sm uppercase tracking-wider">Uptime Reliability</div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}