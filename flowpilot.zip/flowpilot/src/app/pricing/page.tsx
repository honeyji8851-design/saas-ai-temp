"use client";
import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/Button";
import { Check } from "lucide-react";
import { motion } from "framer-motion";

const tiers = [
  {
    name: "Starter",
    price: { monthly: "$0", yearly: "$0" },
    description: "Perfect for individuals and side projects.",
    features: ["5 active workflows", "1,000 runs/month", "Basic analytics", "Community support"],
    cta: "Start for Free",
    popular: false,
  },
  {
    name: "Growth",
    price: { monthly: "$49", yearly: "$39" },
    description: "Ideal for growing teams needing more power.",
    features: ["Unlimited workflows", "50,000 runs/month", "Advanced logic", "Priority email support", "Custom integrations"],
    cta: "Start 14-day Trial",
    popular: true,
  },
  {
    name: "Enterprise",
    price: { monthly: "Custom", yearly: "Custom" },
    description: "Advanced security and scale for large orgs.",
    features: ["Unlimited everything", "Dedicated account manager", "SSO & SAML", "99.9% Uptime SLA", "Custom contracts"],
    cta: "Contact Sales",
    popular: false,
  },
];

export default function PricingPage() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  return (
    <>
      <Navbar />
      <main className="pt-32 pb-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto text-center mb-16">
          <h1 className="text-5xl font-bold tracking-tight text-zinc-900 mb-6">Simple, transparent pricing.</h1>
          <p className="text-xl text-zinc-500 mb-10">Choose the plan that works best for your team.</p>

          {/* Toggle Switch */}
          <div className="flex items-center justify-center gap-4">
            <span className={`text-sm ${billingCycle === 'monthly' ? 'text-black font-medium' : 'text-zinc-400'}`}>Monthly</span>
            <button 
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
              className="w-12 h-6 rounded-full bg-zinc-100 border border-zinc-200 relative transition-colors"
            >
              <motion.div 
                animate={{ x: billingCycle === 'monthly' ? 2 : 24 }}
                className="absolute top-1 w-4 h-4 bg-black rounded-full shadow-sm"
              />
            </button>
            <span className={`text-sm ${billingCycle === 'yearly' ? 'text-black font-medium' : 'text-zinc-400'}`}>
              Yearly <span className="text-emerald-500 font-bold text-xs ml-1">Save 20%</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {tiers.map((tier) => (
            <div 
              key={tier.name}
              className={`relative p-8 rounded-3xl border ${tier.popular ? 'border-black shadow-xl ring-1 ring-black' : 'border-zinc-200'} bg-white`}
            >
              {tier.popular && (
                <span className="absolute -top-4 left-1/2 -translate-x-1/2 bg-black text-white text-[10px] font-bold uppercase tracking-widest py-1 px-3 rounded-full">
                  Most Popular
                </span>
              )}
              <h3 className="text-lg font-bold mb-2">{tier.name}</h3>
              <div className="flex items-baseline gap-1 mb-4">
                <span className="text-4xl font-bold tracking-tight">
                  {billingCycle === 'monthly' ? tier.price.monthly : tier.price.yearly}
                </span>
                {tier.price.monthly !== "Custom" && (
                  <span className="text-zinc-500 text-sm">/mo</span>
                )}
              </div>
              <p className="text-zinc-500 text-sm mb-8 leading-relaxed">{tier.description}</p>
              
              <Button variant={tier.popular ? 'primary' : 'secondary'} className="w-full mb-8">
                {tier.cta}
              </Button>

              <ul className="space-y-4">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3 text-sm text-zinc-600">
                    <Check className="w-4 h-4 text-emerald-500 mt-0.5" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </main>
    </>
  );
}