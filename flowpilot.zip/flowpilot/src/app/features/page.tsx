import { Navbar } from "@/components/layout/Navbar";
import { FeaturesGrid } from "@/components/sections/FeaturesGrid";

export default function FeaturesPage() {
  return (
    <>
      <Navbar />
      <main className="pt-32">
        <div className="max-w-7xl mx-auto px-6 mb-20">
          <h1 className="text-5xl font-bold tracking-tight mb-6">Built for scale.</h1>
          <p className="text-xl text-zinc-500 max-w-2xl">
            Everything you need to automate your complex business logic without the engineering overhead.
          </p>
        </div>
        <FeaturesGrid />
      </main>
    </>
  );
}