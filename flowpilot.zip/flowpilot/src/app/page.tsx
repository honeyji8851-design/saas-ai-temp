import { Navbar } from '@/components/layout/Navbar';
import { Hero } from '@/components/sections/Hero';
import { FeaturesGrid } from '@/components/sections/FeaturesGrid';
import { WorkflowVisual } from '@/components/sections/WorkflowVisual';
import { Button } from '@/components/ui/Button';

export default function Home() {
  return (
    <>
      <Navbar />
      <main className="pt-16">
        <Hero />
        
        <WorkflowVisual />

        <FeaturesGrid />

        {/* Final CTA Section */}
        <section className="py-24 px-6 border-t border-zinc-100">
          <div className="max-w-4xl mx-auto text-center bg-zinc-900 rounded-[32px] p-12 md:p-20 text-white overflow-hidden relative">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to automate your team?</h2>
            <p className="text-zinc-400 text-lg mb-10 max-w-lg mx-auto">
              Join 1,000+ teams who have reclaimed 20+ hours a week with FlowPilot.
            </p>
            <Button variant="secondary" size="lg" className="px-10">Start for Free</Button>
            
            {/* Background design element */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 blur-[100px] rounded-full" />
          </div>
        </section>
      </main>
      
      <footer className="py-12 px-6 border-t border-zinc-100 text-center text-zinc-500 text-sm">
        © 2026 FlowPilot Inc. Built for speed.
      </footer>
    </>
  );
}