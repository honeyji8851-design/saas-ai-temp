"use client";

import { motion } from "framer-motion";
import { Button } from "../ui/Button";
import { DashboardMockup } from "../ui/DashboardMockup";
import { ChevronRight, Sparkles } from "lucide-react";

export const Hero = () => {
  return (
    <section className="relative pt-24 pb-32 overflow-hidden bg-white">
      {/* Background Polish */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[1000px] pointer-events-none -z-10">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[120%] h-full bg-[radial-gradient(circle_at_50%_0%,rgba(59,130,246,0.05),transparent_50%)]" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-grid-pattern opacity-[0.2]" />
      </div>

      <div className="max-w-7xl mx-auto px-6 flex flex-col items-center">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 flex items-center gap-2 px-4 py-1.5 rounded-full border border-slate-200/60 bg-white/50 backdrop-blur-md text-[13px] font-medium text-slate-600 shadow-sm"
        >
          <Sparkles className="w-3.5 h-3.5 text-blue-500" />
          <span>FlowPilot 2.0 is now available</span>
          <ChevronRight className="w-3.5 h-3.5 text-slate-300" />
        </motion.div>

        {/* Typography */}
        <div className="text-center mb-16">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-[52px] md:text-[88px] font-bold tracking-[-0.05em] text-slate-900 leading-[0.9] mb-8"
          >
            Orchestrate your <br /> 
            <span className="text-slate-400">entire workspace.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="max-w-2xl mx-auto text-lg md:text-xl text-slate-500 leading-relaxed"
          >
            The workflow engine built for speed. Connect your tools, 
            automate complex logic, and ship faster than ever.
          </motion.p>
        </div>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center gap-4 mb-24"
        >
          <Button size="lg" className="bg-slate-900 text-white px-10 rounded-full hover:shadow-2xl hover:shadow-blue-500/10 transition-all">
            Start building for free
          </Button>
          <Button variant="secondary" size="lg" className="px-10 rounded-full border border-slate-200 bg-white hover:bg-slate-50">
            Talk to an expert
          </Button>
        </motion.div>

        {/* Triple-Layer Chassis Dashboard */}
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 1, delay: 0.4, ease: [0.23, 1, 0.32, 1] }}
          className="relative w-full max-w-6xl group"
        >
          <div className="absolute -inset-12 bg-blue-500/5 blur-[120px] rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-1000 -z-10" />
          
          {/* Layer 1: The Outer Frame */}
          <div className="rounded-[42px] border border-slate-200/50 bg-slate-50/50 p-2 shadow-2xl">
            {/* Layer 2: The Inner Bezel */}
            <div className="rounded-[36px] border border-slate-200 bg-white p-2.5 shadow-sm">
              {/* Layer 3: The Screen Context */}
              <div className="rounded-[24px] border border-slate-100 overflow-hidden bg-white aspect-video relative shadow-inner">
                 
                 {/* Browser Bar Mock */}
                 <div className="absolute top-0 w-full h-11 border-b border-slate-50 bg-slate-50/40 backdrop-blur-md flex items-center px-6 gap-2 z-10">
                    <div className="flex gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-slate-200" />
                      <div className="w-2.5 h-2.5 rounded-full bg-slate-200" />
                      <div className="w-2.5 h-2.5 rounded-full bg-slate-200" />
                    </div>
                 </div>

                 <div className="h-full pt-11">
                    <DashboardMockup />
                 </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};