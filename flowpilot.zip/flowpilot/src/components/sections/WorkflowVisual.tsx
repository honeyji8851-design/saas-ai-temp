import { Zap, ArrowRight, Database, MessageSquare, Mail } from 'lucide-react';

export const WorkflowVisual = () => (
  <section className="py-24 bg-zinc-50/50 overflow-hidden">
    <div className="max-w-5xl mx-auto px-6 text-center">
      <h2 className="text-3xl font-bold mb-16 text-zinc-900">Build pipelines in minutes</h2>
      
      <div className="relative flex flex-col md:flex-row items-center justify-between gap-8 md:gap-4">
        <StepCard icon={<Database />} label="Data Source" desc="Listen for events" />
        <Connector />
        <StepCard icon={<Zap className="text-yellow-500 fill-yellow-500" />} label="Logic" desc="Filter & Transform" />
        <Connector />
        <StepCard icon={<Mail />} label="Action" desc="Send Email" />
      </div>
    </div>
  </section>
);

const StepCard = ({ icon, label, desc }: any) => (
  <div className="w-48 p-6 bg-white rounded-2xl border border-zinc-200 shadow-soft flex flex-col items-center">
    <div className="p-3 bg-zinc-50 rounded-xl mb-4 text-zinc-600">{icon}</div>
    <div className="font-semibold text-sm">{label}</div>
    <div className="text-xs text-zinc-500 text-center mt-1">{desc}</div>
  </div>
);

const Connector = () => (
  <div className="flex items-center gap-2 text-zinc-300">
    <div className="h-[2px] w-8 md:w-16 bg-zinc-200" />
    <ArrowRight size={16} />
    <div className="h-[2px] w-8 md:w-16 bg-zinc-200" />
  </div>
);