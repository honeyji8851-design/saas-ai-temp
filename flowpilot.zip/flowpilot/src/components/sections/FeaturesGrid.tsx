import { 
  Zap, 
  BarChart3, 
  Users, 
  ShieldCheck, 
  Layers, 
  Globe 
} from "lucide-react";

const features = [
  {
    title: "Instant Automation",
    desc: "Trigger workflows from any event in your stack with sub-second latency.",
    icon: <Zap className="w-6 h-6" />,
  },
  {
    title: "Advanced Analytics",
    desc: "Deep insights into every task execution and bottleneck in your pipeline.",
    icon: <BarChart3 className="w-6 h-6" />,
  },
  {
    title: "Team Collaboration",
    desc: "Work together on shared logic with built-in version control and comments.",
    icon: <Users className="w-6 h-6" />,
  },
  {
    title: "Enterprise Security",
    desc: "End-to-end encryption and SOC2 compliance out of the box.",
    icon: <ShieldCheck className="w-6 h-6" />,
  },
  {
    title: "Extensible API",
    desc: "Build custom integrations with our robust, typed GraphQL API.",
    icon: <Layers className="w-6 h-6" />,
  },
  {
    title: "Global Edge",
    desc: "Workflows run on the edge, ensuring zero latency for global teams.",
    icon: <Globe className="w-6 h-6" />,
  },
];

export const FeaturesGrid = () => {
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-zinc-900 mb-4">
            Powerful features for power users.
          </h2>
          <p className="text-zinc-500 max-w-xl">
            We've built the tools you need to scale from your first automated 
            task to a complex global infrastructure.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
          {features.map((feature, index) => (
            <div key={index} className="group relative">
              <div className="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl border border-zinc-200 bg-white text-zinc-900 shadow-sm transition-all group-hover:border-zinc-900 group-hover:bg-zinc-900 group-hover:text-white">
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold text-zinc-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-zinc-500 leading-relaxed">
                {feature.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};