"use client";
import { motion } from "framer-motion";

export const DashboardMockup = () => {
  return (
    <div className="w-full h-full bg-white flex overflow-hidden font-sans">
      {/* Sidebar Navigation */}
      <div className="w-16 md:w-52 border-r border-slate-100 flex-col p-4 hidden md:flex bg-white">
        <div className="flex items-center gap-3 mb-8 px-2">
          <div className="w-6 h-6 bg-slate-900 rounded-md shadow-sm" />
          <div className="w-20 h-3 bg-slate-200 rounded-full" />
        </div>
        <div className="space-y-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="flex items-center gap-3 px-2">
              <div className="w-4 h-4 bg-slate-100 rounded" />
              <div className={`h-2 rounded-full ${i === 1 ? 'w-24 bg-slate-200' : 'w-16 bg-slate-100'}`} />
            </div>
          ))}
        </div>
      </div>

      {/* Main Panel */}
      <div className="flex-1 bg-[#fcfcfd] p-4 md:p-8">
        <div className="flex justify-between items-center mb-10">
          <div className="space-y-2">
            <div className="w-32 h-4 bg-slate-200 rounded-full" />
            <div className="w-20 h-2 bg-slate-100 rounded-full" />
          </div>
          <div className="w-24 h-9 bg-slate-900 rounded-lg shadow-lg shadow-slate-200" />
        </div>

        {/* Hero Metric Cards */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white border border-slate-200/60 p-4 rounded-xl shadow-[0_2px_4px_rgba(0,0,0,0.02)]">
              <div className="w-10 h-2 bg-slate-100 rounded-full mb-3" />
              <div className="w-16 h-5 bg-slate-200/60 rounded-md" />
            </div>
          ))}
        </div>

        {/* Animated Workflow Canvas */}
        <div className="bg-white border border-slate-200/60 rounded-2xl p-4 md:p-10 shadow-sm relative h-64 border-dashed">
          <svg className="w-full h-full" viewBox="0 0 800 200" fill="none">
            <motion.path
              d="M100 100 C 200 100, 300 40, 400 100 S 600 160, 700 100"
              stroke="#e2e8f0"
              strokeWidth="2"
              strokeDasharray="8 8"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 2, ease: "easeInOut" }}
            />
            
            {/* Animated Data Particle */}
            <motion.circle
              r="5"
              fill="#3b82f6"
              style={{ offsetPath: "path('M100 100 C 200 100, 300 40, 400 100 S 600 160, 700 100')" }}
              animate={{ offsetDistance: ["0%", "100%"] }}
              transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            />

            {[100, 400, 700].map((x, i) => (
              <circle key={i} cx={x} cy={100} r="8" fill="white" stroke={i === 1 ? "#3b82f6" : "#e2e8f0"} strokeWidth="2" />
            ))}
          </svg>
          
          <div className="absolute top-4 right-4 flex gap-2">
             <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
             <div className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">Live Engine</div>
          </div>
        </div>
      </div>
    </div>
  );
};