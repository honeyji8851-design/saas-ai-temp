import Link from 'next/link';
import { Button } from '../ui/Button';

export const Navbar = () => (
  <nav className="fixed top-0 w-full z-50 border-b border-zinc-100 bg-white/80 backdrop-blur-md">
    <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
      <div className="flex items-center gap-10">
        <Link href="/" className="text-xl font-bold tracking-tighter">FlowPilot</Link>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-600">
          <Link href="/features" className="hover:text-black transition-colors">Features</Link>
          <Link href="/pricing" className="hover:text-black transition-colors">Pricing</Link>
          <Link href="/about" className="hover:text-black transition-colors">About</Link>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <Button variant="ghost">Log in</Button>
        <Button>Get Started</Button>
      </div>
    </div>
  </nav>
);